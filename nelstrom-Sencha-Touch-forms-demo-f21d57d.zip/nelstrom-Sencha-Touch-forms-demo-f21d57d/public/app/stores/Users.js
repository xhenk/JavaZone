App.stores.users = new Ext.data.Store({
    model: 'User',
    autoLoad: true
});
